
  # Modernize Website Design

  This is a code bundle for Modernize Website Design. The original project is available at https://www.figma.com/design/o9L6wIVaFFNMYwjpygDQoX/Modernize-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  