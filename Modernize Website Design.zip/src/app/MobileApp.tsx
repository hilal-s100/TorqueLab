import { useState } from "react";
import { ArrowUpRight, Gauge, Menu, ShieldCheck, X } from "lucide-react";

const packages = [
  { name: "STAGE 1", hp: "+42", nm: "+88", detail: "Günlük sürüş için dengeli güç ve tork." },
  { name: "STAGE 2", hp: "+71", nm: "+132", detail: "Donanım yükseltmeleriyle agresif tepki." },
  { name: "STAGE 3", hp: "+108", nm: "+196", detail: "Pist kullanımına özel kalibrasyon." },
];

export default function MobileApp() {
  const [active, setActive] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const selected = packages[active];

  return (
    <main className="mx-auto min-h-screen max-w-md overflow-hidden bg-[#080a0a] text-[#f4f2eb] [font-family:Poppins,sans-serif]">
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-white/10 bg-[#080a0a]/95 px-5 py-4 backdrop-blur">
        <a href="#top" className="flex items-center gap-2.5" aria-label="TorqueLab">
          <span className="grid size-8 place-items-center rounded-full border border-[#d7fa3e] text-[#d7fa3e]"><Gauge size={17} /></span>
          <span className="font-['Poppins'] text-xl font-bold uppercase tracking-wider">Torque<span className="text-[#d7fa3e]">Lab</span></span>
        </a>
        <button onClick={() => setMenuOpen(!menuOpen)} aria-label="Menüyü aç" className="grid size-10 place-items-center rounded-full border border-white/15">
          {menuOpen ? <X size={19} /> : <Menu size={20} />}
        </button>
      </header>

      {menuOpen && <nav className="absolute z-20 w-full max-w-md border-b border-white/10 bg-[#121514] px-5 py-6 font-mono text-xs tracking-[0.12em]"><div className="flex flex-col gap-5"><a href="#hizmetler" onClick={() => setMenuOpen(false)}>HİZMETLER</a><a href="#stage" onClick={() => setMenuOpen(false)}>PERFORMANS</a><a href="#iletisim" onClick={() => setMenuOpen(false)}>İLETİŞİM</a></div></nav>}

      <section id="top" className="relative px-5 pb-12 pt-12">
        <div className="absolute right-[-7rem] top-0 size-64 rounded-full bg-[#d7fa3e]/10 blur-[75px]" />
        <p className="relative font-mono text-[10px] tracking-[0.15em] text-[#d7fa3e]">PERFORMANCE ENGINEERING / 01</p>
        <h1 className="relative mt-5 font-['Poppins'] text-[6.1rem] font-bold uppercase leading-[0.74] tracking-[-0.045em]">Gücü<br /><span className="text-[#d7fa3e]">Uyandır.</span></h1>
        <p className="relative mt-7 max-w-[18rem] text-sm leading-6 text-[#a8aea6]">Motorunuzun potansiyelini veriyle açığa çıkaran, kişisel performans yazılımı.</p>
        <a href="#stage" className="relative mt-8 flex items-center justify-between bg-[#d7fa3e] px-5 py-4 font-mono text-xs font-medium tracking-[0.08em] text-[#10140d]">POTANSİYELİNİ GÖR <ArrowUpRight size={17} /></a>
        <div className="relative mt-10 h-56 overflow-hidden border border-white/10 bg-[#171c19]">
          <div className="absolute -right-10 top-9 h-32 w-[120%] -skew-x-[17deg] rounded-l-[42%] border-y border-white/15 bg-[#222a25]" />
          <div className="absolute bottom-[-1rem] right-6 size-36 rounded-full border-[13px] border-[#080a0a] bg-[radial-gradient(circle,#737d75_0_5%,#202623_6%_24%,#080a0a_25%_31%,#b2b9b2_32%_34%,#161a18_35%)]" />
          <span className="absolute left-4 top-4 font-mono text-[9px] tracking-[0.14em] text-[#d7fa3e]">AUDI S3 / STAGE 2</span>
          <span className="absolute bottom-4 left-4 font-['Poppins'] text-4xl font-bold">420 <small className="font-mono text-[10px] tracking-widest">HP</small></span>
        </div>
      </section>

      <section id="hizmetler" className="bg-[#f1f0e9] px-5 py-12 text-[#11140c]">
        <p className="font-mono text-[10px] tracking-[0.15em] text-[#637057]">HİZMETLER / 02</p>
        <h2 className="mt-3 font-['Poppins'] text-5xl font-bold uppercase leading-[.84]">Ölç. Yaz.<br />His<span className="text-[#6f7e17]">set.</span></h2>
        <div className="mt-8 border-t border-[#11140c]/20">
          {["ECU REMAP", "DYNO PERFORMANCE", "DSG / TCU", "DTC SOLUTIONS"].map((item, index) => <div key={item} className="flex items-center justify-between border-b border-[#11140c]/20 py-4"><span className="font-mono text-[10px] text-[#6a7463]">0{index + 1}</span><span className="font-['Poppins'] text-2xl font-bold">{item}</span><ArrowUpRight size={16} /></div>)}
        </div>
      </section>

      <section id="stage" className="px-5 py-14">
        <p className="font-mono text-[10px] tracking-[0.15em] text-[#d7fa3e]">KALİBRASYON / 03</p>
        <h2 className="mt-3 font-['Poppins'] text-5xl font-bold uppercase leading-[.84]">Senin için<br />ne kadar ileri?</h2>
        <div className="mt-8 flex gap-2">{packages.map((item, index) => <button key={item.name} onClick={() => setActive(index)} className={`flex-1 border px-1 py-3 font-mono text-[10px] tracking-wide ${active === index ? "border-[#d7fa3e] bg-[#d7fa3e] text-[#11140c]" : "border-white/15 text-white/60"}`}>{item.name.replace("STAGE ", "S")}</button>)}</div>
        <article className="mt-3 border border-white/10 bg-[#121514] p-5">
          <div className="flex items-start justify-between"><div><p className="font-mono text-[10px] tracking-[0.12em] text-[#d7fa3e]">{selected.name}</p><p className="mt-3 text-sm leading-6 text-[#a8aea6]">{selected.detail}</p></div><ShieldCheck className="text-[#d7fa3e]" size={21} /></div>
          <div className="mt-8 grid grid-cols-2 border-t border-white/10 pt-4"><div><span className="font-mono text-[9px] tracking-widest text-white/40">GÜÇ</span><div className="font-['Poppins'] text-5xl font-bold text-[#d7fa3e]">{selected.hp}<small className="ml-1 font-mono text-[10px]">HP</small></div></div><div><span className="font-mono text-[9px] tracking-widest text-white/40">TORK</span><div className="font-['Poppins'] text-5xl font-bold">{selected.nm}<small className="ml-1 font-mono text-[10px]">NM</small></div></div></div>
        </article>
      </section>

      <footer id="iletisim" className="bg-[#d7fa3e] px-5 pb-6 pt-12 text-[#11140c]"><p className="font-mono text-[10px] tracking-[.14em]">ARACININ HİKÂYESİ BURADA BAŞLIYOR</p><h2 className="mt-4 font-['Poppins'] text-6xl font-bold uppercase leading-[.78]">Kontrolü<br />eline al.</h2><a href="mailto:hello@torquelab.co" className="mt-9 flex items-center justify-between border-b border-[#11140c] pb-3 font-mono text-xs font-medium tracking-widest">RANDEVU AL <ArrowUpRight size={18} /></a><p className="mt-12 font-mono text-[9px] tracking-[.1em] text-[#4c583d]">© 2026 TORQUE LAB / İSTANBUL</p></footer>
    </main>
  );
}
